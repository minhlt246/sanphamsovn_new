<?php
class AboutControllers{
    public function __construct(){    // phương thức
        include 'view/about.php';
    }        
}
