<?php
class ContactControllers{
    public function __construct(){
        include 'view/contact.php';
    }
}
